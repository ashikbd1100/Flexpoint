module.exports = {
    images: {
      domains: ['github.githubassets.com'],
    },
  };
  
